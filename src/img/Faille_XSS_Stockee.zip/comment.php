<!DOCTYPE html>
<html>
<head>
    <title>Exemple de site avec faille XSS stockée</title>
</head>
<body>
    <?php
    $comment = $_POST['comment'];

    // Stockage du commentaire
    file_put_contents('comments.txt', $comment . "<br>", FILE_APPEND);

    echo "<h1>Votre commentaire a été enregistré.</h1>";
    ?>
</body>
</html>
