<!DOCTYPE html>
<html>
<head>
    <title>Exemple de site avec faille XSS stockée</title>
</head>
<body>
    <h1>Page d'accueil</h1>

    <form action="comment.php" method="POST">
        <label for="comment">Laissez un commentaire :</label>
        <textarea name="comment" id="comment"></textarea>
        <br>
        <input type="submit" value="Envoyer">
    </form>

    <?php
    // Récupération des commentaires stockés
    $comments = file_get_contents('comments.txt');
    echo "<h2>Commentaires précédents :</h2>";
    echo "<p>" . $comments . "</p>";
    ?>
</body>
</html>
